
<section class="page_banner" style="background-image: url('assets/images/shapes/tyre_print_3.svg');">
  <div class="container">
    <ul class="breadcrumb_nav unordered_list">
      <li><a href="/">Home</a></li><li>Booking Details</li>
    </ul>
    <h1 class="page_title wow" data-splitting>Booking Details</h1>
  </div>
</section>

<section class="details_section section_space_lg pb-0">
  <div class="container">
    <div class="row">

      <div class="col-lg-8">
<!--
        <div class="section_heading">
          <h3 class="heading_text wow" data-splitting>Your booking cart</h3>
          <p>We offer a wide range of services. Choose a category below to find out more about each, how to book, and promotional offers.</p>
        </div>
      -->
      
        <livewire:components.cart />

        <hr style="margin-top: 60px">

        <div class="section_heading" style="margin-top: 40px">
          <h3 class="heading_text wow" data-splitting>Choose your services</h3>
          <p>We offer a wide range of services. Choose a category below to find out more about each, how to book, and promotional offers.</p>
        </div>
<!--
        <div class="accordion" id="faq_accordion" style="margin-bottom: 30px">
          <div class="accordion-item">
            <div class="accordion-header" id="headingOne">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                How should brakes work?
              </button>
            </div>
            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#faq_accordion">
              <div class="accordion-body pt-0">
                <p class="m-0">
                  Sit amet dictum sit amet justo donec enim. Aliquam eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis. Viverra suspendisse potenti nullam ac. Semper eget duis at tellus at. Ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. 
                </p>
              </div>
            </div>
          </div>   
        </div>
-->

        <!-- MOT -->
        <x-servis-grupa :grupa="$this->dajServisGrupu(3)" :ispis="'radio'" />          
        <!-- Car Servicing i dodaci 11 -->
        <x-servis-grupa :grupa="$this->dajServisGrupu(2)" :ispis="'radio'" />
        <!-- Wheel Alignment -->
        <x-servis-grupa :grupa="$this->dajServisGrupu(4)" :ispis="'chkbox'" />
        <!-- Brakes -->
        <x-servis-grupa :grupa="$this->dajServisGrupu(5)" :ispis="'chkbox'" />
        <!-- Air Conditioning -->
        <x-servis-grupa :grupa="$this->dajServisGrupu(6)" :ispis="'chkbox'" />
        <!-- Engine Treatments -->
        <x-servis-grupa :grupa="$this->dajServisGrupu(7)" :ispis="'chkbox'" />
        <!-- Diagnostics -->
        <x-servis-grupa :grupa="$this->dajServisGrupu(8)" :ispis="'chkbox'" />
        <!-- Complimentary FREE Checks -->
        <x-servis-grupa :grupa="$this->dajServisGrupu(9)" :ispis="'chkbox'" />
        <!-- Additional Services -->
        <x-servis-grupa :grupa="$this->dajServisGrupu(10)" :ispis="'chkbox'" />

      </div>

      <div class="col-lg-4">
        <aside class="sidebar ps-lg-4">
          <a class="service_pill_item" href="/tyres" style="margin-bottom: 30px">
            <span class="item_icon">
              <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M38.9933 39.3424L37.4178 40.756C36.992 41.0805 36.4896 41.4552 35.9446 41.8043C35.3144 42.2386 34.6672 42.6125 34.0371 42.9114C31.1843 44.4102 27.9227 45.2106 24.6186 45.2106H24.5675C21.1952 45.2021 17.9933 44.3931 15.0383 42.8092L13.1733 41.6936C12.6283 41.3351 12.2111 41.0294 11.8449 40.7228L11.8278 40.7143L11.6575 40.5951L10.2362 39.2922L10.1417 39.1976C6.1989 35.2642 4.03589 30.0695 4.06229 24.5598C4.06995 23.3591 4.18066 22.2265 4.39355 21.0939C4.51277 20.3181 4.66691 19.6198 4.86192 18.9649C4.98966 18.5221 5.15997 18.0529 5.31326 17.6109L5.40693 17.3554C5.70498 16.5379 6.00304 15.8907 6.34367 15.2946C9.3242 9.36762 15.0638 5.23746 21.6806 4.28284C22.3704 4.17298 23.0857 4.11337 23.784 4.10486C24.014 4.07846 24.2533 4.06994 24.5002 4.06994C24.5002 4.06994 24.7131 4.06228 24.7208 4.06228C25.0529 4.06228 25.3424 4.06994 25.6575 4.11337C26.194 4.12189 26.8582 4.1815 27.7354 4.30072C34.3266 5.30644 40.0415 9.47833 43.0383 15.4649C43.4215 16.2399 43.7025 16.8786 43.9069 17.4823C44.1368 17.9848 44.2994 18.5817 44.4434 19.1352C44.6733 19.8846 44.8351 20.6255 44.9211 21.2897C45.0991 22.3108 45.2013 23.4783 45.2098 24.7046C45.1842 30.2739 42.9786 35.4686 38.9933 39.3424ZM24.7293 0.00024092C11.1551 -0.0593697 0.050491 10.9507 0.000247817 24.5258C-0.0602144 38.117 10.9507 49.2301 24.5419 49.2803C38.1085 49.3323 49.2122 38.3299 49.2803 24.7386C49.3229 11.1559 38.3214 0.0513357 24.7293 0.00024092Z" fill="#EDEDED"></path>
                <path fill-rule="evenodd" clip-rule="evenodd" d="M37.4353 37.3763L30.8441 26.5527L42.4937 21.8852C42.6555 22.8134 42.7151 23.768 42.7066 24.7048C42.6981 29.5077 40.8246 34.004 37.4353 37.3763ZM35.8599 38.8155C35.4426 39.122 35.0509 39.4371 34.574 39.7437C34.5655 39.7437 34.5569 39.7607 34.5484 39.7778L27.7358 30.3508C28.2382 30.0783 28.6981 29.7376 29.1068 29.3459L35.8854 38.7806C35.8769 38.7984 35.8769 38.7984 35.8599 38.8155ZM24.5764 42.7242C21.6811 42.7072 18.9134 42.0259 16.4183 40.723L24.5509 31.1342L32.709 40.7997C30.2054 42.0855 27.4471 42.7242 24.5764 42.7242ZM14.5874 39.65L14.5363 39.5989C14.102 39.3349 13.6847 39.0198 13.3441 38.7312L13.2674 38.6707L20.1141 29.2948C20.5144 29.6942 20.9742 30.0357 21.4682 30.2997L14.5874 39.65ZM11.7099 37.2486C8.37086 33.8346 6.53144 29.3459 6.54847 24.56C6.55699 23.6318 6.65066 22.7121 6.79543 21.7668L6.91465 21.8086L18.428 26.5357L11.7099 37.2486ZM7.2638 19.6549C7.39154 19.1695 7.56185 18.6841 7.74069 18.2072C7.7492 18.1979 7.75772 18.1561 7.77475 18.1391L18.8197 21.7839C18.5643 22.2778 18.3854 22.8134 18.2662 23.3678L7.23911 19.723C7.24677 19.706 7.25614 19.6796 7.2638 19.6549ZM21.7918 6.78754L20.8814 19.3398V19.3483H20.8721L8.65188 16.2316C11.3173 11.1902 16.1884 7.67318 21.7918 6.78754ZM20.31 24.1002C19.7905 24.1002 19.3648 23.6829 19.3648 23.1626C19.3648 22.6354 19.7905 22.2182 20.31 22.2182C20.8295 22.2182 21.2553 22.6354 21.2553 23.1626C21.2553 23.6829 20.8295 24.1002 20.31 24.1002ZM21.9459 27.3277C22.4645 27.3277 22.8903 27.7449 22.8903 28.2721C22.8903 28.7924 22.4645 29.2096 21.9459 29.2096C21.4256 29.2096 20.9998 28.7924 20.9998 28.2721C20.9998 27.7449 21.4256 27.3277 21.9459 27.3277ZM24.636 22.0215C26.0837 22.0215 27.2589 23.1975 27.2589 24.6452C27.2589 26.0843 26.0837 27.2595 24.636 27.2595C23.1969 27.2595 22.0217 26.0843 22.0217 24.6452C22.0217 23.1975 23.1969 22.0215 24.636 22.0215ZM24.636 19.0247C25.164 19.0247 25.5813 19.442 25.5813 19.9691C25.5813 20.4895 25.164 20.9067 24.636 20.9067C24.1166 20.9067 23.6908 20.4895 23.6908 19.9691C23.6908 19.442 24.1166 19.0247 24.636 19.0247ZM23.8449 6.59168C23.9122 6.57464 23.9803 6.56613 24.0399 6.56613C24.2188 6.55676 24.3891 6.55676 24.5764 6.55676H24.8319C25.0022 6.55676 25.1981 6.55676 25.5047 6.59168H25.5387L25.4961 18.2072C25.2151 18.1647 24.9256 18.1476 24.636 18.1476C24.3465 18.1476 24.0655 18.1647 23.7845 18.2072L23.8449 6.59168ZM28.2893 28.2721C28.2893 28.7924 27.872 29.2096 27.3441 29.2096C26.8255 29.2096 26.3997 28.7924 26.3997 28.2721C26.3997 27.7449 26.8255 27.3277 27.3441 27.3277C27.872 27.3277 28.2893 27.7449 28.2893 28.2721ZM29.9414 23.1626C29.9414 23.6829 29.5156 24.1002 28.9961 24.1002C28.4767 24.1002 28.0509 23.6829 28.0509 23.1626C28.0509 22.6354 28.4767 22.2182 28.9961 22.2182C29.5156 22.2182 29.9414 22.6354 29.9414 23.1626ZM40.7054 16.3423L28.4426 19.3739L27.6081 6.8216C33.2123 7.73279 38.0569 11.2924 40.7054 16.3423ZM41.591 18.3946C41.7869 18.8629 41.941 19.3824 42.0594 19.8244C42.0594 19.8423 42.0594 19.8423 42.0679 19.8593L31.0059 23.4027C30.9037 22.8483 30.7248 22.3204 30.4864 21.8264L41.5484 18.266C41.5655 18.3179 41.5655 18.3426 41.591 18.3946ZM44.0776 21.3913C43.9925 20.7109 43.8221 20.0126 43.6178 19.3483C43.4815 18.8119 43.3367 18.2754 43.1068 17.7636C42.8769 17.1087 42.5873 16.47 42.2808 15.8475C39.4706 10.2364 34.0545 6.12331 27.6251 5.14314C26.9353 5.05032 26.237 4.97367 25.5557 4.95664C25.2747 4.92173 25.0107 4.91406 24.7297 4.91406C24.4231 4.92173 24.1336 4.91406 23.8526 4.95664C23.1628 4.96516 22.4645 5.02477 21.8003 5.12696C15.3623 6.05433 9.9037 10.1172 7.08497 15.7206C6.72731 16.3423 6.4548 16.9724 6.20784 17.6367C6.02901 18.1476 5.83315 18.6841 5.67986 19.2121C5.484 19.8678 5.34008 20.5491 5.22852 21.2465C5.02415 22.3382 4.92196 23.4274 4.91429 24.56C4.88789 30.0433 7.14458 35.0081 10.7468 38.5941L10.8149 38.6622L12.237 39.9651L12.2966 39.9907C12.7139 40.3483 13.1738 40.6719 13.6166 40.9615L15.439 42.06C18.1555 43.5162 21.2467 44.3507 24.5679 44.3593C27.8465 44.3678 30.9462 43.5758 33.6713 42.1451C34.3015 41.8471 34.9155 41.4809 35.4852 41.0892C35.9621 40.7826 36.4134 40.4505 36.8485 40.1175L38.3976 38.7312C42.0423 35.1877 44.3331 30.2154 44.3586 24.7133C44.3501 23.5884 44.265 22.4736 44.0776 21.3913Z" fill="#EDEDED"></path>
              </svg>
            </span>
            <span class="item_title">
              Get tyres here
            </span>
          </a>
    
          @php
              //<livewire:components.order.lokacija>
          @endphp
          <livewire:components.order.auto>

          <livewire:components.order.termin>
            <livewire:components.order.user>
          <livewire:components.order.summary>
        </aside>
      </div>

    </div>
  </div>
</section>

