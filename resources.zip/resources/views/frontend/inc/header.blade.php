<style>
  .site_header .nav-link { text-transform: capitalize !important; font-weight: 500 !important; color: #111 !important; }
  .cb-cursor.-visible {display: none !important;}
</style>
<header class="site_header sticky sticky-top" style="background:#fff !important; background-image:none !important; position: sticky; top: 0; z-index: 1030;">
    <div class="header_bottom" style="background:#fff !important; background-image:none !important;">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-2 col-5">
            <div class="site_logo">
              <a class="site_link" href="/">
                @php
                $logo = 'logo_330_black.png';
                if($header == 'bijelo')
                  $logo = 'logo_330_white.png';
                @endphp
                <img class="light_theme_logo" src="{{ asset('assets/images/site_logo/' . $logo) }}" alt="{{$chunker['default_picture_alt']}}">
                <img class="dark_theme_logo" src="{{ asset('assets/images/site_logo/logo_330_black.png') }}" alt="{{$chunker['default_picture_alt']}}">
                <!--<img class="light_theme_logo" src="/assets/images/logo.png" alt="{{$chunker['default_picture_alt']}}">
                <img class="dark_theme_logo" src="/assets/images/logo.png" alt="{{$chunker['default_picture_alt']}}">-->
              </a>
            </div>
          </div>
          <div class="col-lg-8 col-2">
            <div class="meni_bg" style="background:#fff !important; background-image:none !important;">
              <x-menu :$header />
            </div>
          </div>
          <div class="col-lg-2 col-5">
            <ul class="header_btns_group unordered_list_end align-items-center">
              <li class="d-none d-md-block">
                <form action="/tyres" method="GET" class="position-relative" style="max-width: 170px;">
                  <input type="search" name="manufacturer" class="form-control rounded-pill pe-4 ps-3 py-1" style="font-size: 13px; border: 1px solid #ddd; height: 32px;" placeholder="">
                  <button type="submit" class="btn p-0 position-absolute" style="right: 10px; top: 50%; transform: translateY(-50%); background: transparent; border: 0;">
                    <i class="far fa-search text-danger" style="font-size: 12px;"></i>
                  </button>
                </form>
              </li>
              <li class="d-lg-none d-block">
                <button class="mobile_menu_btn" type="button" data-bs-toggle="collapse" data-bs-target="#main_menu_dropdown" aria-expanded="false" aria-label="Toggle navigation">
                  <i class="far fa-bars"></i>
                </button>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </header>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Setup mega menus (Fleet, Services, MOT, Tyres, Repairs)
      const megaItems = document.querySelectorAll('.dropdown_fleet_item, .dropdown_services_item, .dropdown_mot_item, .dropdown_tyres_item, .dropdown_repairs_item');
      
      megaItems.forEach(function(item) {
        const link = item.querySelector('a.nav-link');
        const menu = item.querySelector('.fleet_mega_menu, .services_mega_menu, .mot_mega_menu, .tyres_mega_menu, .repairs_mega_menu');
        if (!link || !menu) return;

        function toggleMenu(e) {
          if (e && window.innerWidth < 992) {
            e.preventDefault();
            e.stopPropagation();
            const isOpen = menu.classList.contains('show');
            // Close other mega menus first
            megaItems.forEach(function(other) {
              if (other !== item) {
                const otherMenu = other.querySelector('.fleet_mega_menu, .services_mega_menu, .mot_mega_menu, .tyres_mega_menu, .repairs_mega_menu');
                const otherLink = other.querySelector('a.nav-link');
                if (otherMenu) otherMenu.classList.remove('show');
                other.classList.remove('show');
                if (otherLink) otherLink.setAttribute('aria-expanded', 'false');
              }
            });
            if (isOpen) {
              menu.classList.remove('show');
              item.classList.remove('show');
              link.setAttribute('aria-expanded', 'false');
            } else {
              menu.classList.add('show');
              item.classList.add('show');
              link.setAttribute('aria-expanded', 'true');
            }
          }
        }

        link.addEventListener('click', function(e) {
          toggleMenu(e);
        });
      });

      // Close when clicking outside
      document.addEventListener('click', function(e) {
        megaItems.forEach(function(item) {
          if (!item.contains(e.target)) {
            const menu = item.querySelector('.fleet_mega_menu, .services_mega_menu, .mot_mega_menu, .tyres_mega_menu, .repairs_mega_menu');
            const link = item.querySelector('a.nav-link');
            if (menu) menu.classList.remove('show');
            item.classList.remove('show');
            if (link) link.setAttribute('aria-expanded', 'false');
          }
        });
      });

      // Close on Escape key
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
          megaItems.forEach(function(item) {
            const menu = item.querySelector('.fleet_mega_menu, .services_mega_menu, .mot_mega_menu, .tyres_mega_menu, .repairs_mega_menu');
            const link = item.querySelector('a.nav-link');
            if (menu) menu.classList.remove('show');
            item.classList.remove('show');
            if (link) link.setAttribute('aria-expanded', 'false');
          });
        }
      });
    });
  </script>
