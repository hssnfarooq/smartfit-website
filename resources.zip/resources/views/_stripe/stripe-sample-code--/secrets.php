<?php
// Keep your Stripe API key protected by including it as an environment variable
// or in a private script that does not publicly expose the source code.

// This is your test secret API key.
$stripeSecretKey = 'sk_test_51PdsIHLi2eGpOXQtkSsVQI54vp9VGQeXa3m8Z6Fh0t97AyoGecAHurwM6GHdVqf1MOfZ1WN3r9oqge2uzVlh9UU400XtaKHhYt';